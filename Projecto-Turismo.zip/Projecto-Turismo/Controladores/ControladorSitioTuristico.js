/**
 * Created by Familia Esquite Tuiz on 07/05/2016.
 */
module.exports = function (app){
    return {
        add: function (req, res) {
            var SitioTuristico = app.get('sitioTuristico');
            SitioTuristico.create({
                nombre: req.body.nombre,
                telefono: req.body.telefono,
                descripcion: req.body.descripcion,
                direccion: req.body.direccion,
                imagen: req.body.imagen
            }).then(function (sitioTuristico) {
                res.json(sitioTuristico)
            });
        },
        list: function (req, res) {
            var SitioTuristico = app.get('sitioTuristico');
            SitioTuristico.findAll().then(function (sitioTuristicos) {
                res.json(sitioTuristicos);

            });
        },
        edit: function (res, req) {
            var SitioTuristico = app.get('sitioTuristico');
            SitioTuristico.find(req.body.id_usuario).then(function (sitioTuristico) {
                if (sitioTuristico) {
                    sitioTuristico.updateAttributes({
                        nombre: req.body.nombre,
                        telefono: req.body.telefono,
                        descripcion: req.body.descripcion,
                        direccion: req.body.direccion,
                        imagen: req.body.imagen
                    });
                } else {
                    res.status(404).send({message: 'SitioTuristico no encontrado'})
                }

            });

        },
        delete: function (res, req) {
            var SitioTuristico = app.get('sitioTuristico');
            SitioTuristico.destroy({
                where: {
                    id_sitioTuristico: req.body.id_sitioTuristico
                }
            }).then(function (sitioTuristico) {
                re.json(sitioTuristico);
            });
        },

        prueba: function (res, req) {
            var SitioTuristico = app.get('sitioTuristico');
            SitioTuristico.find(req.body.id_sitioTuristico).then(function (sitioTuristico) {
                if (sitioTuristico) {
                    res.json(sitioTuristico);
                } else {
                    res.status(404).send({message: 'SitioTuristico no encontrado'})
                }
            });
        },

    }
}