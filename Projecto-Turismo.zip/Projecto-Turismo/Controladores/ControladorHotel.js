/**
 * Created by Familia Esquite Tuiz on 07/05/2016.
 */
module.exports = function (app){
    return {
        add: function (req, res) {
            var Hotel = app.get('usuario');
            Usuario.create({
                nombre: req.body.nombre,
                descripcion: req.body.descripcion,
                direccion: req.body.direccion,
                latitud: req.body.latitud,
                longitud: req.body.longitud,
                imagen: req.body.imagen
            }).then(function (usuario) {
                res.json(usuario)
            });
        },
        list: function (req, res) {
            var Hotel = app.get('hotel');
            Hotel.findAll().then(function (hoteles) {
                res.json(hoteles);

            });
        },
        edit: function (res, req) {
            var Hotel = app.get('hotel');
            Hotel.find(req.body.id_hotel).then(function (hotel) {
                if (hotel) {
                    hotel.updateAttributes({
                        nombre: req.body.nombre,
                        descripcion: req.body.descripcion,
                        direccion: req.body.direccion,
                        latitud: req.body.latitud,
                        longitud: req.body.longitud,
                        imagen:req.body.imagen
                    });
                } else {
                    res.status(404).send({message: 'Hotel no encontrado'})
                }

            });

        },
        delete: function (res, req) {
            var Hotel = app.get('hotel');
            Hotel.destroy({
                where: {
                    id_hotel: req.body.id_hotel
                }
            }).then(function (hotel) {
                re.json(hotel);
            });
        },

        prueba: function (res, req) {
            var Hotel = app.get('hotel');
            Hotel.find(req.body.id_hotel).then(function (hotel) {
                if (hotel) {
                    res.json(hotel);
                } else {
                    res.status(404).send({message: 'Hotel no encontrado'})
                }
            });
        },

    }
}