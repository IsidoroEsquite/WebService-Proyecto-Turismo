/**
 * Created by informatica on 06/05/2016.
 */
var ruta= require('express').Router();

   module.exports = (function (app) {
      var Departamento = require('../Controladores/ControladorDepartamento')(app);
      var SitioTuristico = require('../Controladores/ControladorSitioTuristico')(app);
      var Rol = require('../Controladores/ControladorRol')(app);
      var Usuario = require('../Controladores/ControladorUsuario')(app);
      var Hotel = require('../Controladores/ControladorHotel')(app);


    ruta.get('/departamento', Departamento.list);
    ruta.post('/departamento', Departamento.add);
    ruta.put('/departamento', Departamento.edit);
    ruta.delete('/departamento', Departamento.delete);
    ruta.get('/departamento', Departamento.departamentoConLugares);

   return ruta;

      ruta.get('/sitioTuristico', SitioTuristico.list);
      ruta.post('/sitioTuristico', SitioTuristico.add);
      ruta.put('/sitioTuristico', SitioTuristico.edit);
      ruta.delete('/sitioTuristico', SitioTuristico.delete);
     // ruta.get('/departamento', SitioTuristico.departamentoConLugares);

      return ruta;

      ruta.get('/rol', Rol.list);
      ruta.post('/rol', Rol.add);
      ruta.put('/rol', Rol.edit);
      ruta.delete('/rol', Rol.delete);

      return ruta;

      ruta.get('/usuario', Usuario.list);
      ruta.post('/usuario', Usuario.add);
      ruta.put('/usuario', Usuario.edit);
      ruta.delete('/usuario',Usuario.delete);

      return ruta;


      ruta.get('/hotel', Hotel.list);
      ruta.post('/hotel', Hotel.add);
      ruta.put('/hotel', Hotel.edit);
      ruta.delete('/hotel', Hotel.delete);
      return ruta;

});
